import { useState } from "react";
import "./App.css";
import { InventoryButton } from "./components/inventory-button";

function App() {
  const [money, setMoney] = useState(0);

  const handleChange = (e) => {
    setMoney(e.target.value);
  };

  return (
    <div className="App">
      <div>
        <h1>Money: {money}</h1>
        <input type="number" onChange={handleChange} />
      </div>
      <InventoryButton
        name="Ak47"
        price={2700}
        money={money}
        setMoney={setMoney}
      />
      <InventoryButton
        name="M4A1"
        price={2900}
        money={money}
        setMoney={setMoney}
      />
      <InventoryButton
        name="USP"
        price={200}
        money={money}
        setMoney={setMoney}
      />
    </div>
  );
}

export default App;
