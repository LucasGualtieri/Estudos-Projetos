import { useEffect, useState } from "react";
import styled from "styled-components";

const Button = styled.button`
  background-color: ${(props) => props.color};
  margin: 15px;
`;

const DISABLED_COLOR = "#666666";
const ENABLED_COLOR = "#cccccccc";
const BOUGHT_COLOR = "#00ff00FF";

export const InventoryButton = ({ name, price, money, setMoney }) => {
  const [disabled, setDisabled] = useState(false);
  const [isBought, setIsBought] = useState(false);
  const [stateColor, setStateColor] = useState(DISABLED_COLOR);

  useEffect(() => {
    if (isBought) {
    }
  }, [isBought]);

  useEffect(() => {
    if (price > money && !isBought) {
      setDisabled(true);
    } else {
      setDisabled(false);
    }
  }, [money]);

  const handleClick = () => {
    if (price <= money && !isBought) {
      setMoney(money - price);
      setStateColor(BOUGHT_COLOR);
      setIsBought(true);
    } else if (isBought) {
      setMoney(money + price);
      setStateColor(DISABLED_COLOR);
      setIsBought(false);
    }
  };

  return (
    <Button disabled={disabled} onClick={handleClick} color={stateColor}>
      {name}
    </Button>
  );
};
